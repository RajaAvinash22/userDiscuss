export class IShowComments
{
    
    email: string;
    description: string;
    discussion_id: number;
    
}