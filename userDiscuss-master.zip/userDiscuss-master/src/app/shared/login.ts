export class ILogin 
{
    email: string;
    password: string;
}